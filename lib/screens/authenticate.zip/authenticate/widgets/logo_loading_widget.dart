import 'package:flutter/material.dart';

Widget logoLoadingWidget() {
  return const Center(
    child: Text(
      'Logo',
      style: TextStyle(color: Colors.white),
    ),
  );
}